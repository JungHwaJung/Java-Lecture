package exercise;

public class Ex07 {

	public static void main(String[] args) {
		int x = 10;
		int y = 5;
		
		System.out.println( (x>7) && (y<=5) );
		System.out.println( (x%3 == 2) || (y%2 != 1) );
	}

}
