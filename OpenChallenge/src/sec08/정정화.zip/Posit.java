package sec08;

public enum Posit {
	부장, 차장, 과장, 대리, 사원
}
