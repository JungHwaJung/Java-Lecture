package sec04;

public interface MyMulti {
	public abstract int max(int[] array);
	public abstract int min(int[] array);
	public abstract int sum(int[] array);
	public abstract int avg(int[] array);
}
