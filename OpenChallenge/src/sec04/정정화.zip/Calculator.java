package sec04;

public interface Calculator {
	public abstract void add(int a, int b);
	public abstract void substract(int a, int b);
	public abstract void multiply(int a, int b);
}
