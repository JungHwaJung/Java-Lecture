package sec06;

public class EX1 {

	public static void main(String[] args) {
		long num1 = 0;
		long num2 = 0;
		long sum = 0;
		
		for(long i=10; i<=99; i++) {
			num1 += i % 10;
			num2 += i / 10; 
			sum += num1 + num2;
		}
		long num3 = 0;
		long num4 = 0;
		long num5 = 0;
		long num6 = 0;
		long num7 = 0;
		long sum2 = 0;
		
		for(long i=100; i<=1000; i++) {
			num3 += i / 1000;
			num5 += num4 / 100;
			num6 += num5 / 10;
			num7 += num6 % 10;
			
			sum2 += num3 + num4+ num5+ num6+ num7;
		}
		System.out.println("답 : "  + sum + sum2);
	}
}
