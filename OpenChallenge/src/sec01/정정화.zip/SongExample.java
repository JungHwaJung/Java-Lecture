package sec01;

public class SongExample {

	public static void main(String[] args) {
		Song mySong = new Song("Love of My Life", "Queen", "A Night at the Opera", "Freddie Mercury", 1975, 9);
		
		mySong.show();
		
		
	}

}
